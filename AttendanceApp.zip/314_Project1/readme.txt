Directions on Project 1 Interface:
Use the load log (A) button and load roster (D) button to load an attendance log of swipe 
data and roster. These two files must be loaded first in order to perform any of the menu 
functions.
	The B & E buttons (print log and print roster) will display the contents of the log and 
roster respectively, and the C & F buttons (print log count and print roster count) will
display the number of entries in the log and roster files respectively as well.
To use the menu buttons: some of the buttons require extra information to be input by the
user. The information is seperated into data fields as follows - first name, last name, date,
time, and integer number for days attended. Certain functions require different fields to 
be filled out. 
	Please note: The required fields must be filled out BEFORE clicking on the letter that 
requires them. If a letter is clicked without the required fields filled out, a message
will be displayed which says the fields that need to be filled out. Once a user fills them out, they
MUST click submit, and then clicking on the letter will enable the function to be performed.
	For certain functions, the results will be displayed immediately when the function
is performed. For most functions, however, after clicking on a certain letter/function, to
see the results, the user must click on print query (or R) in order to display them. Print
count (or S) also outputs the number of items in the query list.

Here are the functions corresponding to each letter:
G - returns a list of students that did not attend class (no input required)
H - lists all times checking in and out immediately for a given student (requires first & last name)
I - returns a list all check in times for all the students (no input required)
J - returns a list of students who were late (given a time and date)
K/Q - returns the student who entered first on a given date (date input required)
L - prints attendance data immediately for a given student (requires first & last name)
M - returns true or false for whether a student was present on a given date. (requires first & last name, and date)
N - returns a list of students that attended class on a given date (requires a date)
O - returns a list of students that checked in before a given time on a given date (requires date and time)
P - returns a list of students that have attended a particular amount of days (the amount of days is given by the user input for # of attendance days)
R - prints the query list
S - prints the count of the query list

Thank you!

